# Instance-specific configuration
# This file should not be committed to version control

# Override settings for this specific deployment
DEBUG = True
SECRET_KEY = 'your-instance-specific-secret-key'
