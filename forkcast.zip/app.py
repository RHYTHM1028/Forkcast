#!/usr/bin/env python3
"""
Forkcast Application Entry Point for Pterodactyl Deployment

This is the main entry point that Pterodactyl will execute.
"""

from forkcast import create_app

# Create Flask application instance
app = create_app()

if __name__ == '__main__':
    # For production, we'll use the built-in server on Pterodactyl
    # In a real production environment, you'd use Gunicorn or similar
    import os
    
    # Get port from environment or use default
    port = int(os.environ.get('PORT', 5000))
    host = os.environ.get('HOST', '0.0.0.0')
    
    # Run the application
    print(f"🚀 Starting Forkcast on {host}:{port}")
    app.run(host=host, port=port, debug=False)
